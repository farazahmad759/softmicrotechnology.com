            <!-- Primary Navigation
        ============================================= -->
            <nav id="primary-menu">

                <ul>
                    <li class="">
                        <a href="/">
                            <div>Home</div>
                        </a>
                    </li>
                    <li class=""><a href="/services">
                            <div>Services</div>
                        </a>
                    </li>
                    <li><a href="/products">
                            <div>Products</div>
                        </a>
                        <ul>
                            <li>
                                <a href="#">
                                    <div><i class="icon-stack"></i>Sliders</div>
                                </a>
                                <ul>
                                    <li>
                                        <a href="#">
                                            <div>Revolution Slider</div>
                                        </a>
                                        <ul>
                                            <li><a href="#">
                                                    <div>Premium Templates</div>
                                                </a></li>
                                            <li><a href="#">
                                                    <div>Full Screen</div>
                                                </a></li>
                                            <li><a href="#">
                                                    <div>Full Width</div>
                                                </a></li>
                                            <li><a href="#">
                                                    <div>Kenburns Effect</div>
                                                </a></li>
                                            <li><a href="#">
                                                    <div>HTML5 Video</div>
                                                </a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">
                                            <div>Nivo Slider</div>
                                        </a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class=""><a href="/contact">
                            <div>Contact Us</div>
                        </a>
                    </li>
                    <li class=""><a href="/about">
                            <div>About Us</div>
                        </a>
                    </li>
                </ul>


            </nav><!-- #primary-menu end --><?php /**PATH C:\Users\Faraz Ahmad\laravel-apps\softmicrotechnology.com\resources\views/layout/partials/nav.blade.php ENDPATH**/ ?>